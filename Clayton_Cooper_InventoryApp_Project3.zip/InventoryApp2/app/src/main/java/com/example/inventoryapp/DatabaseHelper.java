package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * DatabaseHelper manages all SQLite database operations for InventoryApp.
 *
 * Tables:
 *   - users: stores login credentials (username + password)
 *   - inventory: stores inventory items (name, category, quantity)
 *
 * This class follows the singleton helper pattern provided by SQLiteOpenHelper.
 * All CRUD operations (Create, Read, Update, Delete) for both tables are here.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database metadata
    private static final String DATABASE_NAME    = "InventoryApp.db";
    private static final int    DATABASE_VERSION = 1;

    // --- Users table constants ---
    private static final String TABLE_USERS      = "users";
    private static final String COL_USER_ID       = "id";
    private static final String COL_USERNAME      = "username";
    private static final String COL_PASSWORD      = "password";

    // --- Inventory table constants ---
    private static final String TABLE_INVENTORY  = "inventory";
    private static final String COL_ITEM_ID       = "id";
    private static final String COL_ITEM_NAME     = "name";
    private static final String COL_ITEM_CATEGORY = "category";
    private static final String COL_ITEM_QUANTITY = "quantity";

    /**
     * Constructor passes database metadata to the parent SQLiteOpenHelper.
     *
     * @param context Application context used to open or create the database
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Called when the database is created for the first time.
     * Creates both the users and inventory tables.
     *
     * @param db The newly created SQLite database
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table to persist login credentials across sessions
        String createUsersTable =
            "CREATE TABLE " + TABLE_USERS + " (" +
            COL_USER_ID   + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COL_USERNAME  + " TEXT UNIQUE NOT NULL, " +
            COL_PASSWORD  + " TEXT NOT NULL)";
        db.execSQL(createUsersTable);

        // Create inventory table to store all tracked items
        String createInventoryTable =
            "CREATE TABLE " + TABLE_INVENTORY + " (" +
            COL_ITEM_ID       + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COL_ITEM_NAME     + " TEXT NOT NULL, " +
            COL_ITEM_CATEGORY + " TEXT NOT NULL, " +
            COL_ITEM_QUANTITY + " INTEGER NOT NULL)";
        db.execSQL(createInventoryTable);
    }

    /**
     * Called when the database version number changes.
     * Drops existing tables and recreates them (simple migration strategy).
     *
     * @param db         The existing SQLite database
     * @param oldVersion Old schema version number
     * @param newVersion New schema version number
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // =========================================================================
    // USER CRUD OPERATIONS
    // =========================================================================

    /**
     * Inserts a new user record into the users table.
     * Returns true if the insert succeeded, false if the username already exists.
     *
     * @param username Desired username (must be unique)
     * @param password Plain-text password
     * @return true on success, false if username is taken
     */
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        // insertOrThrow would crash on duplicate; insertOrIgnore returns -1 on conflict
        long rowId = db.insert(TABLE_USERS, null, values);
        db.close();

        // rowId is -1 if the insert was ignored (duplicate username)
        return rowId != -1;
    }

    /**
     * Checks whether the provided username and password match a record in the database.
     *
     * @param username Username entered by the user
     * @param password Password entered by the user
     * @return true if credentials are valid, false otherwise
     */
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Query for a row matching both username and password
        String query = "SELECT * FROM " + TABLE_USERS +
                       " WHERE " + COL_USERNAME + "=? AND " + COL_PASSWORD + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});

        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        db.close();

        return isValid;
    }

    // =========================================================================
    // INVENTORY CRUD OPERATIONS
    // =========================================================================

    /**
     * Inserts a new inventory item into the database.
     *
     * @param item InventoryItem to save (id field is ignored; assigned by SQLite)
     * @return The row ID of the new record, or -1 on failure
     */
    public long addItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME,     item.getName());
        values.put(COL_ITEM_CATEGORY, item.getCategory());
        values.put(COL_ITEM_QUANTITY, item.getQuantity());

        long rowId = db.insert(TABLE_INVENTORY, null, values);
        db.close();

        return rowId;
    }

    /**
     * Retrieves all inventory items from the database, ordered by item name.
     *
     * @return List of InventoryItem objects; empty list if none exist
     */
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Select all rows ordered alphabetically by item name
        Cursor cursor = db.rawQuery(
            "SELECT * FROM " + TABLE_INVENTORY + " ORDER BY " + COL_ITEM_NAME + " ASC",
            null
        );

        // Map each cursor row to an InventoryItem object
        if (cursor.moveToFirst()) {
            do {
                int    id       = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_ID));
                String name     = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME));
                String category = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_CATEGORY));
                int    quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_QUANTITY));

                itemList.add(new InventoryItem(id, name, category, quantity));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return itemList;
    }

    /**
     * Updates an existing inventory item's quantity in the database.
     * Used when a user edits the quantity of an item in the grid.
     *
     * @param itemId      The SQLite row ID of the item to update
     * @param newQuantity The new quantity value to save
     * @return Number of rows affected (should be 1 on success)
     */
    public int updateItemQuantity(int itemId, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_ITEM_QUANTITY, newQuantity);

        int rowsAffected = db.update(
            TABLE_INVENTORY,
            values,
            COL_ITEM_ID + "=?",
            new String[]{String.valueOf(itemId)}
        );

        db.close();
        return rowsAffected;
    }

    /**
     * Updates an existing inventory item's full record (name, category, quantity).
     *
     * @param item InventoryItem containing the updated values; id must be valid
     * @return Number of rows affected
     */
    public int updateItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME,     item.getName());
        values.put(COL_ITEM_CATEGORY, item.getCategory());
        values.put(COL_ITEM_QUANTITY, item.getQuantity());

        int rowsAffected = db.update(
            TABLE_INVENTORY,
            values,
            COL_ITEM_ID + "=?",
            new String[]{String.valueOf(item.getId())}
        );

        db.close();
        return rowsAffected;
    }

    /**
     * Deletes an inventory item from the database by its row ID.
     *
     * @param itemId SQLite row ID of the item to delete
     * @return Number of rows deleted (should be 1 on success)
     */
    public int deleteItem(int itemId) {
        SQLiteDatabase db = this.getWritableDatabase();

        int rowsDeleted = db.delete(
            TABLE_INVENTORY,
            COL_ITEM_ID + "=?",
            new String[]{String.valueOf(itemId)}
        );

        db.close();
        return rowsDeleted;
    }
}
