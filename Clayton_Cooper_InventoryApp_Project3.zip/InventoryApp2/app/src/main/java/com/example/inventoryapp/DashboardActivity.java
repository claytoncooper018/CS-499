package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * DashboardActivity is the main screen of the app.
 *
 * It displays all inventory items in a scrollable RecyclerView "grid" and
 * allows the user to:
 *   - Add new items  (navigates to AddItemActivity)
 *   - Delete items   (via inline Delete button in each row)
 *   - Update qty     (via tap-to-edit on the Qty cell)
 *   - View all items (loaded fresh from the SQLite database on each resume)
 *
 * When an item's quantity reaches zero, the app attempts to send an SMS alert
 * if the SEND_SMS permission was granted. If permission was denied, the rest of
 * the app continues working without sending an SMS.
 */
public class DashboardActivity extends AppCompatActivity
        implements InventoryAdapter.OnItemActionListener {

    // Database helper handles all SQLite operations
    private DatabaseHelper    dbHelper;

    // Adapter and backing list for the RecyclerView
    private InventoryAdapter  adapter;
    private List<InventoryItem> itemList;

    // UI references
    private RecyclerView recyclerViewInventory;
    private TextView     textViewEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize the database connection
        dbHelper = new DatabaseHelper(this);

        // Bind UI elements
        recyclerViewInventory = findViewById(R.id.recyclerViewInventory);
        textViewEmpty         = findViewById(R.id.textViewEmpty);
        Button buttonAddItem  = findViewById(R.id.buttonAddItem);

        // Navigate to AddItemActivity when the user taps "+ Add Item"
        buttonAddItem.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, AddItemActivity.class);
            startActivity(intent);
        });

        // Set up the RecyclerView with a LinearLayoutManager (vertical list)
        recyclerViewInventory.setLayoutManager(new LinearLayoutManager(this));

        // Load and display the inventory
        loadInventory();
    }

    /**
     * Refresh the inventory list every time this screen comes back into focus.
     * This ensures data added or changed elsewhere is always reflected here.
     */
    @Override
    protected void onResume() {
        super.onResume();
        loadInventory();
    }

    /**
     * Fetches all inventory items from the database and attaches them to the adapter.
     * Shows an empty-state message if the inventory has no items yet.
     */
    private void loadInventory() {
        // Pull the latest data from SQLite
        itemList = dbHelper.getAllItems();

        if (adapter == null) {
            // First load: create and attach the adapter
            adapter = new InventoryAdapter(this, itemList, this);
            recyclerViewInventory.setAdapter(adapter);
        } else {
            // Subsequent loads: update the existing adapter's data in place
            adapter.notifyDataSetChanged();
        }

        // Toggle the empty-state message
        if (itemList.isEmpty()) {
            textViewEmpty.setVisibility(View.VISIBLE);
            recyclerViewInventory.setVisibility(View.GONE);
        } else {
            textViewEmpty.setVisibility(View.GONE);
            recyclerViewInventory.setVisibility(View.VISIBLE);
        }
    }

    // =========================================================================
    // InventoryAdapter.OnItemActionListener callbacks
    // =========================================================================

    /**
     * Called by the adapter when the user confirms deletion of an item.
     * Removes the item from the database and refreshes the list.
     *
     * @param item The inventory item to delete
     */
    @Override
    public void onDelete(InventoryItem item) {
        int rowsDeleted = dbHelper.deleteItem(item.getId());

        if (rowsDeleted > 0) {
            Toast.makeText(this, "\"" + item.getName() + "\" deleted.", Toast.LENGTH_SHORT).show();
            loadInventory();  // Refresh the grid to reflect the deletion
        } else {
            Toast.makeText(this, "Error deleting item.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Called by the adapter when the user saves a new quantity for an item.
     * Updates the database and, if the new quantity is zero, sends an SMS alert
     * (only if the SEND_SMS permission was previously granted).
     *
     * @param item        The inventory item being updated
     * @param newQuantity The new quantity value entered by the user
     */
    @Override
    public void onQuantityUpdated(InventoryItem item, int newQuantity) {
        int rowsUpdated = dbHelper.updateItemQuantity(item.getId(), newQuantity);

        if (rowsUpdated > 0) {
            Toast.makeText(this,
                "Quantity for \"" + item.getName() + "\" updated to " + newQuantity + ".",
                Toast.LENGTH_SHORT).show();

            // Trigger a low-stock SMS alert if the item hit zero
            if (newQuantity == 0) {
                sendLowStockAlert(item.getName());
            }

            loadInventory();  // Refresh grid so the new value is displayed
        } else {
            Toast.makeText(this, "Error updating quantity.", Toast.LENGTH_SHORT).show();
        }
    }

    // =========================================================================
    // SMS Alert Logic
    // =========================================================================

    /**
     * Sends an SMS alert to the device's own number when an item reaches zero stock.
     *
     * Permission check: if the user denied SEND_SMS, this method does nothing
     * and the app continues functioning normally without any crash or error.
     *
     * @param itemName Name of the inventory item that reached zero
     */
    private void sendLowStockAlert(String itemName) {
        // Check whether the user granted SMS permission at runtime
        boolean smsGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        if (!smsGranted) {
            // Permission was denied — silently skip sending SMS, app keeps running
            return;
        }

        try {
            // Use the device's loopback number so the alert goes to the user themselves
            String phoneNumber  = "5554"; // Emulator loopback; real device uses own number
            String alertMessage = "⚠️ Low Stock Alert: \"" + itemName
                                  + "\" is out of stock (quantity = 0). Please reorder!";

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, alertMessage, null, null);

            Toast.makeText(this,
                "Low-stock SMS alert sent for \"" + itemName + "\".",
                Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            // Log the error but don't crash the app — SMS is a non-critical feature
            Toast.makeText(this, "Could not send SMS alert: " + e.getMessage(),
                           Toast.LENGTH_SHORT).show();
        }
    }
}
